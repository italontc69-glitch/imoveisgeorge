import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import FloatingWhatsApp from "./components/FloatingWhatsApp";
import SiteFooter from "./components/SiteFooter";

const PropertyDetails = lazy(() => import("./pages/PropertyDetails.tsx"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard.tsx"));
const Catalogo = lazy(() => import("./pages/Catalogo.tsx"));
const NotFound = lazy(() => import("./pages/NotFound.tsx"));

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <FloatingWhatsApp />
        <Suspense fallback={<div className="min-h-screen bg-white" />}>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/imovel/:id" element={<PropertyDetails />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/catalogo" element={<Catalogo />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
        <SiteFooter />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
