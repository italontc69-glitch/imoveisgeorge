import { useLocation } from "react-router-dom";
import { MessageCircle } from "lucide-react";
import { WHATSAPP_DEFAULT_URL } from "@/lib/contact";

const FloatingWhatsApp = () => {
  const { pathname } = useLocation();
  if (pathname.startsWith("/admin")) return null;

  return (
    <a
      href={WHATSAPP_DEFAULT_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar no WhatsApp"
      className="fixed z-40 bottom-5 right-5 w-14 h-14 rounded-full bg-green-600 hover:bg-green-700 text-white shadow-lg shadow-green-900/20 flex items-center justify-center transition-transform active:scale-95 hover:scale-105"
    >
      <MessageCircle className="w-6 h-6" />
    </a>
  );
};

export default FloatingWhatsApp;
