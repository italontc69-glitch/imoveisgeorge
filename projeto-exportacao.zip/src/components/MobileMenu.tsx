import { useState } from "react";
import { createPortal } from "react-dom";
import { Link } from "react-router-dom";
import { Menu, X, Home, Building2, User, Phone, Lock } from "lucide-react";

const MobileMenu = () => {
  const [open, setOpen] = useState(false);

  return (
    <div className="md:hidden">
      <button
        onClick={() => setOpen(true)}
        className="p-2 rounded-full text-white"
        style={{ backgroundColor: "rgba(15,23,42,0.8)" }}
        aria-label="Abrir menu"
      >
        <Menu className="w-6 h-6" />
      </button>

      {open &&
        createPortal(
          <div className="fixed inset-0" style={{ zIndex: 99999 }}>
            {/* Backdrop */}
            <div
              className="absolute inset-0"
              style={{ backgroundColor: "rgba(0,0,0,0.7)" }}
              onClick={() => setOpen(false)}
            />

            {/* Panel */}
            <div
              className="absolute top-0 right-0 h-full flex flex-col"
              style={{
                width: "80vw",
                maxWidth: 320,
                backgroundColor: "#0F172A",
              }}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-6 pb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
                <div className="flex items-center gap-2">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center"
                    style={{
                      border: "2px solid rgba(255,255,255,0.4)",
                      transform: "rotate(45deg)",
                    }}
                  >
                    <span className="text-white font-serif font-bold text-xs" style={{ transform: "rotate(-45deg)" }}>G</span>
                  </div>
                  <span className="font-serif text-white font-semibold text-sm">George Imóveis</span>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-full text-white"
                  style={{ backgroundColor: "rgba(255,255,255,0.1)" }}
                  aria-label="Fechar menu"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Navigation */}
              <nav className="flex flex-col gap-1 flex-1 p-6">
                {[
                  { label: "Início", to: "/", icon: Home },
                  { label: "Imóveis", to: "/#imoveis", icon: Building2 },
                  { label: "Sobre Nós", to: "/#sobre", icon: User },
                  { label: "Contato", to: "/#contato", icon: Phone },
                ].map((item) => (
                  <Link
                    key={item.label}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-4 text-white rounded-xl px-4 py-4 text-base font-medium"
                    style={{ transition: "background 0.2s" }}
                    onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "rgba(255,255,255,0.1)")}
                    onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "transparent")}
                  >
                    <item.icon className="w-5 h-5" style={{ color: "rgba(255,255,255,0.7)" }} />
                    {item.label}
                  </Link>
                ))}
              </nav>

              {/* Footer */}
              <div className="p-6 pt-0 mt-auto" style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }}>
                <Link
                  to="/admin"
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium mt-4"
                  style={{ color: "rgba(255,255,255,0.5)" }}
                >
                  <Lock className="w-4 h-4" />
                  Acesso Restrito
                </Link>
                <p className="text-xs text-center mt-4" style={{ color: "rgba(255,255,255,0.3)" }}>CRECI-RN 3.906</p>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
};

export default MobileMenu;
