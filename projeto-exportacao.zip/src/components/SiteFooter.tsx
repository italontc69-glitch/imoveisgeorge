import { useLocation } from "react-router-dom";

const SiteFooter = () => {
  const { pathname } = useLocation();
  if (pathname.startsWith("/admin")) return null;

  return (
    <footer className="w-full bg-zinc-950 py-6 px-6 text-center">
      <p className="text-sm text-white/70">
        Esse site foi desenvolvido por{" "}
        <span className="font-bold text-purple-400 tracking-wide">
          Escaly Agency
        </span>
      </p>
    </footer>
  );
};

export default SiteFooter;
