import { useState } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabaseClient";

export const AdminLogin = ({ onLogin }: { onLogin: () => void }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const { data, error: signErr } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    if (signErr || !data.user) {
      setLoading(false);
      setError(signErr?.message || "Falha no login.");
      return;
    }

    const { data: isAdmin, error: roleErr } = await supabase.rpc("has_role", {
      _user_id: data.user.id,
      _role: "admin",
    });

    setLoading(false);
    if (roleErr || !isAdmin) {
      await supabase.auth.signOut();
      setError("Usuário sem permissão de administrador.");
      return;
    }
    onLogin();
  };

  const inputCls =
    "w-full bg-white/[0.03] border border-white/[0.06] rounded-2xl px-4 py-3 text-[13px] text-zinc-100 placeholder:text-zinc-600 outline-none focus:border-white/20 focus:bg-white/[0.05] transition-all duration-300";

  return (
    <div className="min-h-screen bg-[#08090b] flex items-center justify-center px-4 font-[Inter,sans-serif] relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-zinc-500/[0.04] blur-3xl" />
      </div>
      <div className="w-full max-w-sm relative">
        <div className="text-center mb-10">
          <div className="inline-flex w-12 h-12 rounded-2xl bg-gradient-to-br from-zinc-700 to-zinc-900 border border-white/10 items-center justify-center shadow-[inset_0_1px_0_rgba(255,255,255,0.06),0_10px_40px_-10px_rgba(0,0,0,0.8)] mb-5">
            <span className="text-sm font-semibold tracking-tighter text-zinc-100">G</span>
          </div>
          <p className="text-[10px] uppercase tracking-[0.22em] text-zinc-500 mb-1">Cockpit · Acesso restrito</p>
          <h1 className="text-lg font-light text-zinc-100 tracking-tight">Painel Administrativo</h1>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-gradient-to-b from-white/[0.04] to-white/[0.01] border border-white/[0.08] rounded-3xl p-6 space-y-4 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.9)]"
        >
          {error && (
            <p className="text-red-400 text-[11px] text-center bg-red-500/10 border border-red-500/20 rounded-xl py-2.5 animate-in fade-in slide-in-from-top-2 duration-300">
              {error}
            </p>
          )}
          <div>
            <label className="text-[10px] uppercase tracking-[0.14em] text-zinc-500 mb-1.5 block">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputCls}
              required
            />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-[0.14em] text-zinc-500 mb-1.5 block">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={inputCls}
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full h-12 rounded-2xl bg-zinc-100 hover:bg-white text-zinc-900 font-medium text-[12px] uppercase tracking-[0.14em] transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-60 hover:shadow-[0_0_30px_rgba(255,255,255,0.15)] active:scale-[0.98]"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            Entrar
          </button>
        </form>
      </div>
    </div>
  );
};
