import { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, LayoutGrid, Home, Sparkles, PlusCircle, Settings } from "lucide-react";

interface AdminShellProps {
  children: ReactNode;
  onLogout: () => void;
  activeTab?: TabKey;
  onTabChange?: (tab: TabKey) => void;
  onAdd?: () => void;
}

export type TabKey = "dashboard" | "meus" | "gerenciar" | "adicionar" | "config";

const tabs: { key: TabKey; label: string; icon: typeof Home }[] = [
  { key: "dashboard", label: "Dashboard", icon: LayoutGrid },
  { key: "meus", label: "Meus", icon: Home },
  { key: "gerenciar", label: "Gerenciar", icon: Sparkles },
  { key: "adicionar", label: "Adicionar", icon: PlusCircle },
  { key: "config", label: "Configurações", icon: Settings },
];

export const AdminShell = ({
  children,
  onLogout,
  activeTab = "dashboard",
  onTabChange,
  onAdd,
}: AdminShellProps) => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#f4f5f7] text-zinc-900 font-[Inter,sans-serif] flex flex-col">
      {/* Top bar minimal */}
      <header className="sticky top-0 z-30 bg-[#f4f5f7]/85 backdrop-blur-xl border-b border-zinc-200/70">
        <div className="max-w-2xl mx-auto px-5 h-12 flex items-center justify-between">
          <button
            onClick={() => navigate("/")}
            className="text-[12px] text-zinc-500 hover:text-zinc-900 transition-colors"
          >
            ← Site
          </button>
          <button
            onClick={onLogout}
            className="text-[12px] text-zinc-500 hover:text-red-500 transition-colors"
          >
            Sair
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-2xl w-full mx-auto px-5 py-6 pb-28">{children}</main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-xl border-t border-zinc-200">
        <div className="max-w-2xl mx-auto px-2 py-2 flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="flex flex-col items-center gap-0.5 px-2 py-1.5 text-zinc-500 hover:text-zinc-900 transition-colors"
            aria-label="Voltar"
          >
            <ArrowLeft className="w-5 h-5" strokeWidth={1.8} />
            <span className="text-[10px] font-medium">Voltar</span>
          </button>

          {tabs.map(({ key, label, icon: Icon }) => {
            const active = activeTab === key;
            const handleClick = () => {
              if (key === "adicionar" && onAdd) onAdd();
              else onTabChange?.(key);
            };
            return (
              <button
                key={key}
                onClick={handleClick}
                className={`flex flex-col items-center gap-0.5 px-2 py-1.5 transition-colors ${
                  active ? "text-[#0070f3]" : "text-zinc-500 hover:text-zinc-900"
                }`}
              >
                <Icon className="w-5 h-5" strokeWidth={active ? 2.2 : 1.8} />
                <span className="text-[10px] font-medium">{label}</span>
              </button>
            );
          })}
        </div>
        <div className="h-[env(safe-area-inset-bottom)]" />
      </nav>
    </div>
  );
};
