import { Pencil, Trash2, BedDouble, Bath, Maximize, MapPin, ImageIcon } from "lucide-react";

interface PropertyCardProps {
  property: any;
  onEdit: () => void;
  onDelete: () => void;
  formatBRL: (n: number) => string;
}

export const PropertyCard = ({ property: p, onEdit, onDelete, formatBRL }: PropertyCardProps) => (
  <div className="rounded-2xl bg-white border border-zinc-200/70 shadow-[0_1px_2px_rgba(16,24,40,0.04),0_4px_16px_-8px_rgba(16,24,40,0.08)] p-3 transition-all duration-300 hover:shadow-[0_4px_24px_-8px_rgba(16,24,40,0.18)]">
    <div className="flex gap-3">
      <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 bg-zinc-100 border border-zinc-200/70">
        {p.imagem_capa ? (
          <img src={p.imagem_capa} alt={p.titulo} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ImageIcon className="w-5 h-5 text-zinc-400" strokeWidth={1.5} />
          </div>
        )}
      </div>

      <div className="flex-1 min-w-0 flex flex-col justify-between">
        <div>
          <h3 className="font-semibold text-[13px] text-zinc-900 truncate">{p.titulo}</h3>
          <p className="text-[11px] text-zinc-500 flex items-center gap-1 mt-0.5">
            <MapPin className="w-3 h-3" strokeWidth={1.8} />
            <span className="truncate">{p.localizacao || "Sem localização"}</span>
          </p>
        </div>

        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2.5 text-zinc-500">
            <span className="flex items-center gap-1 text-[10px]">
              <BedDouble className="w-3 h-3" strokeWidth={1.8} />
              {p.quartos}
            </span>
            <span className="flex items-center gap-1 text-[10px]">
              <Bath className="w-3 h-3" strokeWidth={1.8} />
              {p.banheiros}
            </span>
            <span className="flex items-center gap-1 text-[10px]">
              <Maximize className="w-3 h-3" strokeWidth={1.8} />
              {p.area_m2}m²
            </span>
          </div>
          <p className="text-[#0070f3] font-bold text-[12px] tabular-nums">
            {p.preco_formatado || formatBRL(Number(p.preco) || 0)}
          </p>
        </div>
      </div>

      <div className="flex flex-col items-center justify-center gap-1.5">
        <button
          onClick={onEdit}
          className="w-8 h-8 rounded-full bg-zinc-100 hover:bg-[#0070f3] hover:text-white text-zinc-600 transition-all duration-200 active:scale-90 flex items-center justify-center"
          aria-label="Editar"
        >
          <Pencil className="w-3.5 h-3.5" strokeWidth={1.8} />
        </button>
        <button
          onClick={onDelete}
          className="w-8 h-8 rounded-full bg-zinc-100 hover:bg-red-500 hover:text-white text-zinc-600 transition-all duration-200 active:scale-90 flex items-center justify-center"
          aria-label="Excluir"
        >
          <Trash2 className="w-3.5 h-3.5" strokeWidth={1.8} />
        </button>
      </div>
    </div>
  </div>
);
