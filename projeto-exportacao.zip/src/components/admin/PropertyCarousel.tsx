import { useRef, useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { PropertyCard } from "./PropertyCard";

interface PropertyCarouselProps {
  items: any[];
  formatBRL: (n: number) => string;
  onEdit: (p: any) => void;
  onDelete: (id: string) => void;
}

export const PropertyCarousel = ({ items, formatBRL, onEdit, onDelete }: PropertyCarouselProps) => {
  const scrollerRef = useRef<HTMLDivElement>(null);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const updateArrows = () => {
    const el = scrollerRef.current;
    if (!el) return;
    setCanPrev(el.scrollLeft > 4);
    setCanNext(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  };

  useEffect(() => {
    updateArrows();
    const el = scrollerRef.current;
    if (!el) return;
    el.addEventListener("scroll", updateArrows, { passive: true });
    window.addEventListener("resize", updateArrows);
    return () => {
      el.removeEventListener("scroll", updateArrows);
      window.removeEventListener("resize", updateArrows);
    };
  }, [items.length]);

  const scrollBy = (dir: 1 | -1) => {
    const el = scrollerRef.current;
    if (!el) return;
    const amount = Math.max(el.clientWidth * 0.85, 280);
    el.scrollBy({ left: dir * amount, behavior: "smooth" });
  };

  return (
    <div className="relative -mx-5">
      <div
        ref={scrollerRef}
        className="flex flex-row flex-nowrap gap-4 overflow-x-auto overflow-y-hidden pl-5 pr-8 pb-3 snap-x snap-mandatory scroll-smooth [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
        style={{ WebkitOverflowScrolling: "touch" }}
      >
        {items.map((p) => (
          <div
            key={p.id}
            className="snap-start shrink-0 grow-0 basis-[85%] sm:basis-[420px] max-w-[460px]"
          >
            <PropertyCard
              property={p}
              formatBRL={formatBRL}
              onEdit={() => onEdit(p)}
              onDelete={() => onDelete(p.id)}
            />
          </div>
        ))}
      </div>

      {canPrev && (
        <button
          onClick={() => scrollBy(-1)}
          className="flex absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white border border-zinc-200 shadow-md text-zinc-700 hover:text-[#0070f3] hover:border-[#0070f3] transition-all items-center justify-center active:scale-90 z-10"
          aria-label="Anterior"
        >
          <ChevronLeft className="w-4 h-4" strokeWidth={2} />
        </button>
      )}
      {canNext && (
        <button
          onClick={() => scrollBy(1)}
          className="flex absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white border border-zinc-200 shadow-md text-zinc-700 hover:text-[#0070f3] hover:border-[#0070f3] transition-all items-center justify-center active:scale-90 z-10"
          aria-label="Próximo"
        >
          <ChevronRight className="w-4 h-4" strokeWidth={2} />
        </button>
      )}
    </div>
  );
};
