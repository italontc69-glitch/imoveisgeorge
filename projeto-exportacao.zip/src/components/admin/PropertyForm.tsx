import { RefObject } from "react";
import { Upload, Loader2, X, Sparkles, BedDouble, Bath, Car, Ruler, Image as ImageIcon } from "lucide-react";

interface PropertyFormProps {
  editId: string | null;
  form: any;
  photos: string[];
  uploading: boolean;
  saving: boolean;
  fileInputRef: RefObject<HTMLInputElement>;
  onClose: () => void;
  onSave: () => void;
  updateField: (key: string, value: string | number | boolean) => void;
  onPhotos: (e: React.ChangeEvent<HTMLInputElement>) => void;
  removePhoto: (idx: number) => void;
}

const inputCls =
  "w-full bg-white border border-zinc-200 rounded-xl px-4 py-3 text-[14px] text-zinc-900 placeholder:text-zinc-400 outline-none focus:border-[#0070f3] focus:ring-2 focus:ring-[#0070f3]/10 transition-all";

const labelCls = "text-[13px] font-medium text-zinc-700 mb-1.5 block";

const sectionTitle = "text-[15px] font-semibold text-zinc-900 mb-3 flex items-center gap-2";

const card = "bg-white rounded-2xl border border-zinc-200/70 shadow-[0_1px_2px_rgba(16,24,40,0.04),0_4px_16px_-8px_rgba(16,24,40,0.08)] p-5";

const dropzone =
  "w-full border-2 border-dashed border-[#0070f3]/40 hover:border-[#0070f3] hover:bg-[#0070f3]/5 rounded-2xl p-6 text-center transition-all cursor-pointer";

export const PropertyForm = ({
  editId, form, photos, uploading, saving, fileInputRef,
  onClose, onSave, updateField, onPhotos, removePhoto,
}: PropertyFormProps) => (
  <div className="space-y-5">
    {/* Header */}
    <div className="flex items-start justify-between">
      <div>
        <p className="text-[11px] uppercase tracking-[0.16em] text-zinc-500 mb-1">
          {editId ? "Edição" : "Cadastro"}
        </p>
        <h1 className="text-2xl font-bold text-zinc-900 tracking-tight">
          {editId ? "Editar Imóvel" : "Adicionar Novo Imóvel"}
        </h1>
      </div>
      <button
        onClick={onClose}
        className="w-9 h-9 rounded-full bg-white border border-zinc-200 hover:bg-zinc-50 text-zinc-500 hover:text-zinc-900 transition-all flex items-center justify-center shrink-0"
        aria-label="Fechar"
      >
        <X className="w-4 h-4" strokeWidth={1.8} />
      </button>
    </div>

    {/* Destaque na Home */}
    <div className={card}>
      <label className="flex items-start gap-3 cursor-pointer">
        <input
          type="checkbox"
          checked={!!form.destaque}
          onChange={(e) => updateField("destaque", e.target.checked)}
          className="mt-1 w-4 h-4 rounded border-zinc-300 text-[#0070f3] focus:ring-[#0070f3]"
        />
        <div className="flex-1">
          <div className="flex items-center gap-1.5 text-[14px] font-medium text-zinc-900">
            <Sparkles className="w-4 h-4 text-[#0070f3]" strokeWidth={2} />
            Destacar na Home
          </div>
          <p className="text-[12px] text-zinc-500 mt-0.5">
            Imóveis marcados aparecem no carrossel principal da home (até 6).
          </p>
        </div>
      </label>
    </div>

    {/* Informações Básicas */}
    <div className={card}>
      <h2 className={sectionTitle}>Informações Básicas</h2>
      <div className="space-y-3">
        <div>
          <label className={labelCls}>Título do Imóvel</label>
          <input
            value={form.titulo}
            onChange={(e) => updateField("titulo", e.target.value)}
            className={inputCls}
            placeholder="Ex: Apartamento Vista Mar — Barra da…"
          />
        </div>
        <div>
          <label className={labelCls}>Descrição Longa</label>
          <textarea
            value={form.descricao}
            onChange={(e) => updateField("descricao", e.target.value)}
            rows={4}
            className={`${inputCls} resize-none`}
            placeholder="Descreva os diferenciais do imóvel…"
          />
        </div>
        <div>
          <label className={labelCls}>Palavras-chave (SEO/Busca)</label>
          <input
            value={form.palavras_chave || ""}
            onChange={(e) => updateField("palavras_chave", e.target.value)}
            className={inputCls}
            placeholder="luxo, vista mar, varanda gourmet…"
          />
        </div>
        <div>
          <label className={labelCls}>Preço (R$)</label>
          <input
            type="number"
            min={0}
            value={form.preco}
            onChange={(e) => updateField("preco", +e.target.value)}
            className={inputCls}
            placeholder="2850000"
          />
        </div>
        <div>
          <label className={labelCls}>Localização</label>
          <input
            value={form.localizacao}
            onChange={(e) => updateField("localizacao", e.target.value)}
            className={inputCls}
            placeholder="Bairro, Cidade — UF"
          />
        </div>
        <div>
          <label className={labelCls}>Tipo</label>
          <select
            value={form.tipo}
            onChange={(e) => updateField("tipo", e.target.value)}
            className={`${inputCls} appearance-none cursor-pointer`}
          >
            <option value="Casa">Casa</option>
            <option value="Apartamento">Apartamento</option>
            <option value="Terreno">Terreno</option>
            <option value="Comercial">Comercial</option>
            <option value="Empreendimento">Empreendimento</option>
          </select>
        </div>
      </div>
    </div>

    {/* Características */}
    <div className={card}>
      <h2 className={sectionTitle}>Características</h2>
      <div className="grid grid-cols-2 gap-3">
        {[
          { k: "quartos", l: "Quartos", icon: BedDouble },
          { k: "banheiros", l: "Banheiros", icon: Bath },
          { k: "vagas", l: "Vagas", icon: Car },
          { k: "area_m2", l: "Metragem (m²)", icon: Ruler },
        ].map(({ k, l, icon: Icon }) => (
          <div key={k}>
            <label className={`${labelCls} flex items-center gap-1.5`}>
              <Icon className="w-3.5 h-3.5 text-[#0070f3]" strokeWidth={2} />
              {l}
            </label>
            <input
              type="number"
              min={0}
              value={form[k]}
              onChange={(e) => updateField(k, +e.target.value)}
              className={inputCls}
              placeholder="0"
            />
          </div>
        ))}
      </div>
    </div>

    {/* Galeria de Fotos */}
    <div className={card}>
      <h2 className={sectionTitle}>
        <ImageIcon className="w-4 h-4 text-[#0070f3]" strokeWidth={2} />
        Galeria de Fotos
      </h2>

      {photos.length > 0 && (
        <div className="grid grid-cols-3 gap-2 mb-4">
          {photos.map((photo, i) => (
            <div key={i} className="relative group aspect-square">
              <img
                src={photo}
                alt=""
                className="w-full h-full rounded-xl object-cover border border-zinc-200"
              />
              {i === 0 && (
                <span className="absolute top-1.5 left-1.5 text-[9px] uppercase tracking-wider bg-[#0070f3] text-white px-1.5 py-0.5 rounded-md font-semibold">
                  Capa
                </span>
              )}
              <button
                onClick={() => removePhoto(i)}
                className="absolute -top-1.5 -right-1.5 w-6 h-6 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all shadow-lg"
              >
                <X className="w-3 h-3 text-white" strokeWidth={2.4} />
              </button>
            </div>
          ))}
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={onPhotos}
        className="hidden"
      />

      <div className="space-y-3">
        {[
          { label: "Foto de Capa", hint: "Imagem principal exibida nos cards" },
          { label: "Fotos da Sala", hint: "Ambiente social" },
          { label: "Fotos da Cozinha", hint: "Cozinha e copa" },
          { label: "Fotos dos Quartos", hint: "Suítes e dormitórios" },
          { label: "Fotos dos Banheiros", hint: "Lavabos e banheiros" },
          { label: "Fotos da Área Externa", hint: "Quintal, varanda, piscina" },
          { label: "Fotos da Fachada", hint: "Vista externa do imóvel" },
          { label: "Outras Fotos", hint: "Demais ambientes e detalhes" },
        ].map(({ label, hint }) => (
          <button
            key={label}
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className={dropzone}
          >
            {uploading ? (
              <Loader2 className="w-5 h-5 text-[#0070f3] mx-auto mb-2 animate-spin" />
            ) : (
              <Upload className="w-5 h-5 text-[#0070f3] mx-auto mb-2" strokeWidth={1.8} />
            )}
            <p className="text-[13px] font-medium text-zinc-700">{label}</p>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              {uploading ? "Enviando…" : hint}
            </p>
          </button>
        ))}
      </div>
    </div>

    {/* Save button */}
    <button
      onClick={onSave}
      disabled={saving}
      className="w-full h-12 rounded-2xl bg-[#0070f3] hover:bg-[#0060df] text-white font-semibold text-[14px] transition-all flex items-center justify-center gap-2 disabled:opacity-60 shadow-[0_4px_12px_rgba(0,112,243,0.3)] active:scale-[0.98]"
    >
      {saving && <Loader2 className="w-4 h-4 animate-spin" />}
      {editId ? "Salvar Alterações" : "Cadastrar Imóvel"}
    </button>
  </div>
);
