interface StatCardProps {
  label: string;
  value: string | number;
}

export const StatCard = ({ label, value }: StatCardProps) => (
  <div className="rounded-2xl bg-white border border-zinc-200/70 shadow-[0_1px_2px_rgba(16,24,40,0.04),0_4px_16px_-8px_rgba(16,24,40,0.08)] px-5 py-4 transition-all duration-300 hover:shadow-[0_2px_4px_rgba(16,24,40,0.06),0_8px_24px_-8px_rgba(16,24,40,0.12)]">
    <p className="text-[12px] text-zinc-500 font-medium">{label}</p>
    <p className="text-3xl font-bold text-[#0070f3] tracking-tight mt-1 tabular-nums">
      {value}
    </p>
  </div>
);
