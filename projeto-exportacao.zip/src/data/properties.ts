import property1 from "@/assets/property-1.jpg";
import property2 from "@/assets/property-2.jpg";
import property3 from "@/assets/property-3.jpg";
import property4 from "@/assets/property-4.jpg";
import property5 from "@/assets/property-5.jpg";
import property6 from "@/assets/property-6.jpg";

export interface Property {
  id: string;
  img: string;
  images: string[];
  title: string;
  price: string;
  beds: number;
  baths: number;
  area: number;
  garage: number;
  location: string;
  description: string;
  categories: { label: string; images: string[] }[];
}

export const properties: Property[] = [
  {
    id: "casa-de-luxo-em-pipa",
    img: property1,
    images: [property1, property2, property3],
    title: "Casa de Luxo em Pipa",
    price: "R$ 2.850.000",
    beds: 4,
    baths: 3,
    area: 320,
    garage: 3,
    location: "Pipa, Tibau do Sul/RN",
    description:
      "Uma residência excepcional situada em uma das praias mais desejadas do Nordeste. Com arquitetura contemporânea, esta casa oferece 4 suítes amplas, sala de estar integrada com pé-direito duplo, cozinha gourmet equipada e uma área de lazer completa com piscina de borda infinita e vista panorâmica para o mar. Acabamentos de altíssimo padrão, iluminação planejada e paisagismo tropical compõem este verdadeiro refúgio de luxo.",
    categories: [
      { label: "Sala", images: [property1] },
      { label: "Cozinha", images: [property2] },
      { label: "Áreas Externas", images: [property3] },
    ],
  },
  {
    id: "apartamento-vista-mar",
    img: property2,
    images: [property2, property1, property4],
    title: "Apartamento Vista Mar",
    price: "R$ 1.200.000",
    beds: 3,
    baths: 2,
    area: 145,
    garage: 2,
    location: "Areia Preta, Natal/RN",
    description:
      "Apartamento sofisticado com vista permanente para o mar de Natal. Ampla varanda gourmet, 3 quartos sendo 1 suíte master com closet, sala de estar e jantar integradas, e cozinha americana com acabamentos premium. Condomínio com infraestrutura completa: piscina, academia, salão de festas e segurança 24h.",
    categories: [
      { label: "Sala", images: [property2] },
      { label: "Quartos", images: [property1] },
      { label: "Áreas Externas", images: [property4] },
    ],
  },
  {
    id: "mansao-no-campo",
    img: property3,
    images: [property3, property5, property6],
    title: "Mansão no Campo",
    price: "R$ 4.500.000",
    beds: 6,
    baths: 5,
    area: 580,
    garage: 4,
    location: "Extremoz, Grande Natal/RN",
    description:
      "Mansão imponente em condomínio fechado com total privacidade e contato com a natureza. São 6 suítes, sala de cinema, adega climatizada, escritório, piscina aquecida, campo de futebol e quadra de tênis. Terreno de 2.000m² com paisagismo assinado e sistema de automação residencial completo.",
    categories: [
      { label: "Sala", images: [property3] },
      { label: "Quartos", images: [property5] },
      { label: "Áreas Externas", images: [property6] },
    ],
  },
  {
    id: "cobertura-panoramica",
    img: property4,
    images: [property4, property2, property1],
    title: "Cobertura Panorâmica",
    price: "R$ 3.100.000",
    beds: 3,
    baths: 3,
    area: 210,
    garage: 3,
    location: "Petrópolis, Natal/RN",
    description:
      "Cobertura duplex com vista 360° da cidade de Natal. Terraço privativo com piscina e espaço gourmet, 3 suítes com varanda individual, sala ampla com lareira decorativa e acabamentos em mármore e porcelanato importado. Localização privilegiada no bairro mais nobre da capital potiguar.",
    categories: [
      { label: "Sala", images: [property4] },
      { label: "Quartos", images: [property2] },
      { label: "Áreas Externas", images: [property1] },
    ],
  },
  {
    id: "villa-tropical-beira-mar",
    img: property5,
    images: [property5, property3, property6],
    title: "Villa Tropical Beira-Mar",
    price: "R$ 5.200.000",
    beds: 5,
    baths: 4,
    area: 400,
    garage: 3,
    location: "Cotovelo, Parnamirim/RN",
    description:
      "Villa exclusiva à beira-mar com acesso direto à praia. Arquitetura tropical com madeira de lei e vidro, integrando perfeitamente os ambientes internos e externos. 5 suítes, sala de estar com pé-direito triplo, deck com piscina de borda infinita e jardim tropical. Um verdadeiro paraíso particular no litoral potiguar.",
    categories: [
      { label: "Sala", images: [property5] },
      { label: "Quartos", images: [property3] },
      { label: "Áreas Externas", images: [property6] },
    ],
  },
  {
    id: "residencia-moderna",
    img: property6,
    images: [property6, property4, property5],
    title: "Residência Moderna",
    price: "R$ 1.950.000",
    beds: 4,
    baths: 3,
    area: 260,
    garage: 2,
    location: "Capim Macio, Natal/RN",
    description:
      "Residência de linhas contemporâneas em condomínio de alto padrão. Projeto arquitetônico assinado com 4 suítes, home office, sala de estar e jantar integradas com iluminação natural abundante. Área gourmet completa, piscina com deck em madeira e jardim vertical. Localização estratégica próxima ao Parque da Cidade.",
    categories: [
      { label: "Sala", images: [property6] },
      { label: "Quartos", images: [property4] },
      { label: "Áreas Externas", images: [property5] },
    ],
  },
];
