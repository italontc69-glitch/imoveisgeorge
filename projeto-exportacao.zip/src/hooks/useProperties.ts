import { useState, useEffect, useCallback } from "react";
import { properties as defaultProperties, type Property } from "@/data/properties";
import { supabase } from "@/lib/supabaseClient";

const BUCKET = "imoveis";

// ---------- Mapper DB -> Property ----------
function mapDbRow(row: any): Property {
  const imagens: string[] =
    Array.isArray(row.imagens) && row.imagens.length > 0
      ? row.imagens
      : row.imagem_capa
        ? [row.imagem_capa]
        : [];

  const precoFormatado =
    row.preco_formatado ||
    (typeof row.preco === "number"
      ? row.preco.toLocaleString("pt-BR", {
          style: "currency",
          currency: "BRL",
          maximumFractionDigits: 0,
        })
      : "Sob consulta");

  return {
    id: row.id,
    img: row.imagem_capa || imagens[0] || "",
    images: imagens,
    title: row.titulo,
    price: precoFormatado,
    beds: row.quartos ?? 0,
    baths: row.banheiros ?? 0,
    area: Number(row.area_m2 ?? 0),
    garage: row.vagas ?? 0,
    location: row.localizacao ?? "",
    description: row.descricao ?? "",
    categories: [
      { label: "Galeria", images: imagens.length ? imagens : [row.imagem_capa || ""] },
    ],
  };
}

// =====================================================================
// LISTAGEM PÚBLICA (Home / Detalhes) — Supabase + fallback estático
// =====================================================================
export function useProperties() {
  const [all, setAll] = useState<Property[]>(() => [...defaultProperties]);

  const fetchAll = useCallback(async () => {
    const { data, error } = await supabase
      .from("imoveis")
      .select("*")
      .eq("ativo", true)
      .order("created_at", { ascending: false });

    if (error) {
      return;
    }
    if (data && data.length > 0) {
      setAll(data.map(mapDbRow));
    } else {
      setAll([...defaultProperties]);
    }
  }, []);

  useEffect(() => {
    fetchAll();

    // Realtime: qualquer mudança na tabela atualiza Home/Detalhes
    const channel = supabase
      .channel("imoveis-changes")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "imoveis" },
        () => fetchAll()
      )
      .subscribe();

    const handler = () => fetchAll();
    window.addEventListener("properties_updated", handler);

    return () => {
      supabase.removeChannel(channel);
      window.removeEventListener("properties_updated", handler);
    };
  }, [fetchAll]);

  return all;
}

// =====================================================================
// ADMIN — CRUD via Supabase
// =====================================================================
export interface PropertyInput {
  id?: string;
  titulo: string;
  preco: number;            // numérico (ex: 1500000)
  preco_formatado?: string; // opcional, se quiser exibir custom
  localizacao: string;
  tipo: string;             // Casa | Apartamento | Terreno | Comercial
  quartos: number;
  banheiros: number;
  vagas: number;
  area_m2: number;
  descricao: string;
  imagem_capa: string;      // URL
  imagens: string[];        // URLs
  ativo?: boolean;
}

export function usePropertyAdmin() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("imoveis")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      setError(error.message);
      setItems([]);
    } else {
      setError(null);
      setItems(data || []);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchAll();
    const channel = supabase
      .channel("imoveis-admin")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "imoveis" },
        () => fetchAll()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchAll]);

  const addProperty = useCallback(async (input: PropertyInput) => {
    const { data: userData } = await supabase.auth.getUser();
    const owner_id = userData.user?.id ?? null;

    const { error } = await supabase.from("imoveis").insert({
      ...input,
      ativo: input.ativo ?? true,
      owner_id,
    });
    if (error) throw error;
    window.dispatchEvent(new Event("properties_updated"));
  }, []);

  const updateProperty = useCallback(async (id: string, input: Partial<PropertyInput>) => {
    const { error } = await supabase.from("imoveis").update(input).eq("id", id);
    if (error) throw error;
    window.dispatchEvent(new Event("properties_updated"));
  }, []);

  const deleteProperty = useCallback(async (id: string) => {
    const { error } = await supabase.from("imoveis").delete().eq("id", id);
    if (error) throw error;
    window.dispatchEvent(new Event("properties_updated"));
  }, []);

  return { items, loading, error, addProperty, updateProperty, deleteProperty, refetch: fetchAll };
}

// =====================================================================
// Upload de imagens para Supabase Storage (bucket "imoveis")
// =====================================================================
export async function uploadPropertyImage(file: File): Promise<string> {
  if (file.size > 5 * 1024 * 1024) {
    throw new Error("Imagem maior que 5MB.");
  }
  const ext = file.name.split(".").pop() || "jpg";
  const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

  const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type,
  });
  if (error) throw error;

  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

// Mantido p/ compat (não usado mais no admin novo)
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
