export const CONTACT_PHONE = "+558491269731";
export const CONTACT_TEL = "tel:+558491269731";
export const WHATSAPP_BASE =
  "https://api.whatsapp.com/send?phone=558491269731";

// Sempre usamos o link oficial puro, sem parâmetros adicionais.
export const buildWhatsAppUrl = (_text?: string) => WHATSAPP_BASE;

export const WHATSAPP_DEFAULT_URL = WHATSAPP_BASE;
