import { supabase } from "@/lib/supabaseClient";
import { uploadPropertyImage } from "@/hooks/useProperties";
import property1 from "@/assets/property-1.jpg";
import property2 from "@/assets/property-2.jpg";
import property3 from "@/assets/property-3.jpg";
import property4 from "@/assets/property-4.jpg";
import property5 from "@/assets/property-5.jpg";
import property6 from "@/assets/property-6.jpg";

const formatBRL = (n: number) =>
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

type Seed = {
  titulo: string;
  preco: number;
  localizacao: string;
  tipo: string;
  quartos: number;
  banheiros: number;
  vagas: number;
  area_m2: number;
  descricao: string;
  imagens: string[]; // bundled URLs
};

const SEEDS: Seed[] = [
  {
    titulo: "Casa de Luxo em Pipa",
    preco: 2850000,
    localizacao: "Pipa, Tibau do Sul/RN",
    tipo: "Casa",
    quartos: 4, banheiros: 3, vagas: 3, area_m2: 320,
    descricao:
      "Uma residência excepcional situada em uma das praias mais desejadas do Nordeste. Com arquitetura contemporânea, esta casa oferece 4 suítes amplas, sala de estar integrada com pé-direito duplo, cozinha gourmet equipada e uma área de lazer completa com piscina de borda infinita e vista panorâmica para o mar.",
    imagens: [property1, property2, property3],
  },
  {
    titulo: "Apartamento Vista Mar",
    preco: 1200000,
    localizacao: "Areia Preta, Natal/RN",
    tipo: "Apartamento",
    quartos: 3, banheiros: 2, vagas: 2, area_m2: 145,
    descricao:
      "Apartamento sofisticado com vista permanente para o mar de Natal. Ampla varanda gourmet, 3 quartos sendo 1 suíte master com closet, sala de estar e jantar integradas, e cozinha americana com acabamentos premium.",
    imagens: [property2, property1, property4],
  },
  {
    titulo: "Mansão no Campo",
    preco: 4500000,
    localizacao: "Extremoz, Grande Natal/RN",
    tipo: "Casa",
    quartos: 6, banheiros: 5, vagas: 4, area_m2: 580,
    descricao:
      "Mansão imponente em condomínio fechado com total privacidade e contato com a natureza. São 6 suítes, sala de cinema, adega climatizada, escritório, piscina aquecida, campo de futebol e quadra de tênis.",
    imagens: [property3, property5, property6],
  },
  {
    titulo: "Cobertura Panorâmica",
    preco: 3100000,
    localizacao: "Petrópolis, Natal/RN",
    tipo: "Apartamento",
    quartos: 3, banheiros: 3, vagas: 3, area_m2: 210,
    descricao:
      "Cobertura duplex com vista 360° da cidade de Natal. Terraço privativo com piscina e espaço gourmet, 3 suítes com varanda individual, sala ampla com lareira decorativa e acabamentos em mármore e porcelanato importado.",
    imagens: [property4, property2, property1],
  },
  {
    titulo: "Villa Tropical Beira-Mar",
    preco: 5200000,
    localizacao: "Cotovelo, Parnamirim/RN",
    tipo: "Casa",
    quartos: 5, banheiros: 4, vagas: 3, area_m2: 400,
    descricao:
      "Villa exclusiva à beira-mar com acesso direto à praia. Arquitetura tropical com madeira de lei e vidro, integrando perfeitamente os ambientes internos e externos.",
    imagens: [property5, property3, property6],
  },
  {
    titulo: "Residência Moderna",
    preco: 1950000,
    localizacao: "Capim Macio, Natal/RN",
    tipo: "Casa",
    quartos: 4, banheiros: 3, vagas: 2, area_m2: 260,
    descricao:
      "Residência de linhas contemporâneas em condomínio de alto padrão. Projeto arquitetônico assinado com 4 suítes, home office, sala de estar e jantar integradas com iluminação natural abundante.",
    imagens: [property6, property4, property5],
  },
];

async function urlToFile(url: string, filename: string): Promise<File> {
  const res = await fetch(url);
  const blob = await res.blob();
  return new File([blob], filename, { type: blob.type || "image/jpeg" });
}

export async function seedExampleProperties(
  onProgress?: (msg: string) => void,
): Promise<{ inserted: number }> {
  const { data: userData } = await supabase.auth.getUser();
  const owner_id = userData.user?.id ?? null;
  if (!owner_id) throw new Error("Sessão expirada. Faça login novamente.");

  // Evita duplicar: se já existe algum imóvel com um dos títulos, pula esse.
  const { data: existing } = await supabase
    .from("imoveis")
    .select("titulo");
  const existingTitles = new Set((existing ?? []).map((r: any) => r.titulo));

  let inserted = 0;
  for (let i = 0; i < SEEDS.length; i++) {
    const s = SEEDS[i];
    if (existingTitles.has(s.titulo)) {
      onProgress?.(`(${i + 1}/${SEEDS.length}) Pulando "${s.titulo}" — já existe.`);
      continue;
    }
    onProgress?.(`(${i + 1}/${SEEDS.length}) Enviando fotos de "${s.titulo}"…`);

    const uploadedUrls: string[] = [];
    for (let j = 0; j < s.imagens.length; j++) {
      const file = await urlToFile(s.imagens[j], `${s.titulo}-${j + 1}.jpg`);
      const url = await uploadPropertyImage(file);
      uploadedUrls.push(url);
    }

    onProgress?.(`(${i + 1}/${SEEDS.length}) Salvando "${s.titulo}"…`);
    const { error } = await supabase.from("imoveis").insert({
      titulo: s.titulo,
      preco: s.preco,
      preco_formatado: formatBRL(s.preco),
      localizacao: s.localizacao,
      tipo: s.tipo,
      quartos: s.quartos,
      banheiros: s.banheiros,
      vagas: s.vagas,
      area_m2: s.area_m2,
      descricao: s.descricao,
      imagem_capa: uploadedUrls[0],
      imagens: uploadedUrls,
      ativo: true,
      owner_id,
    });
    if (error) throw error;
    inserted++;
  }

  window.dispatchEvent(new Event("properties_updated"));
  return { inserted };
}
