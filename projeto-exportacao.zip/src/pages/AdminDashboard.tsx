import { useState, useRef, useEffect } from "react";
import { Loader2, Search, Plus, Download } from "lucide-react";
import { usePropertyAdmin, uploadPropertyImage, type PropertyInput } from "@/hooks/useProperties";
import { supabase } from "@/lib/supabaseClient";
import { toast } from "sonner";
import { AdminLogin } from "@/components/admin/AdminLogin";
import { AdminShell, type TabKey } from "@/components/admin/AdminShell";
import { StatCard } from "@/components/admin/StatCard";
import { PropertyCard } from "@/components/admin/PropertyCard";
import { PropertyForm } from "@/components/admin/PropertyForm";
import { PropertyCarousel } from "@/components/admin/PropertyCarousel";
import { seedExampleProperties } from "@/lib/seedProperties";

const emptyForm = {
  titulo: "", preco: 0, localizacao: "", tipo: "Casa",
  quartos: 0, banheiros: 0, area_m2: 0, vagas: 0, descricao: "",
  palavras_chave: "", destaque: false,
};

const formatBRL = (n: number) =>
  n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

const AdminDashboard = () => {
  const [authReady, setAuthReady] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const { items, loading, addProperty, updateProperty, deleteProperty } = usePropertyAdmin();

  const [activeTab, setActiveTab] = useState<TabKey>("dashboard");
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [photos, setPhotos] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [query, setQuery] = useState("");
  const [seeding, setSeeding] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const autoSeededRef = useRef(false);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        setAuthenticated(false);
        return;
      }
      supabase
        .rpc("has_role", { _user_id: session.user.id, _role: "admin" })
        .then(({ data }) => setAuthenticated(!!data));
    });

    supabase.auth.getSession().then(async ({ data }) => {
      if (data.session) {
        const { data: isAdmin } = await supabase.rpc("has_role", {
          _user_id: data.session.user.id,
          _role: "admin",
        });
        setAuthenticated(!!isAdmin);
      }
      setAuthReady(true);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!authenticated || loading || items.length > 0 || seeding || autoSeededRef.current) return;

    autoSeededRef.current = true;
    setSeeding(true);
    const toastId = toast.loading("Sincronizando imóveis da Home no admin…");

    seedExampleProperties((msg) => {
      toast.loading(msg, { id: toastId });
    })
      .then(({ inserted }) => {
        toast.success(
          inserted === 0
            ? "Os imóveis da Home já estão disponíveis no admin."
            : `${inserted} imóvel(eis) da Home adicionado(s) em Gerenciar.`,
          { id: toastId },
        );
      })
      .catch((err: any) => {
        autoSeededRef.current = false;
        toast.error(err.message || "Falha ao sincronizar os imóveis da Home.", {
          id: toastId,
        });
      })
      .finally(() => {
        setSeeding(false);
      });
  }, [authenticated, loading, items.length, seeding]);

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#f4f5f7] flex items-center justify-center">
        <Loader2 className="w-5 h-5 text-zinc-400 animate-spin" />
      </div>
    );
  }

  if (!authenticated) return <AdminLogin onLogin={() => setAuthenticated(true)} />;

  const totalValue = items.reduce((acc, p) => acc + (Number(p.preco) || 0), 0);
  const ativos = items.filter((i) => i.ativo).length;
  const pausados = items.length - ativos;
  const formatTotal = (n: number) =>
    n >= 1_000_000
      ? `R$ ${(n / 1_000_000).toFixed(1)}M`
      : n >= 1000
      ? `R$ ${(n / 1000).toFixed(0)}K`
      : `R$ ${n}`;
  const filtered = items.filter((p) =>
    !query.trim()
      ? true
      : (p.titulo + " " + (p.localizacao || "")).toLowerCase().includes(query.toLowerCase())
  );

  const openNew = () => {
    setForm(emptyForm);
    setPhotos([]);
    setEditId(null);
    setShowForm(true);
  };

  const openEdit = (p: any) => {
    setForm({
      titulo: p.titulo ?? "",
      preco: Number(p.preco) || 0,
      localizacao: p.localizacao ?? "",
      tipo: p.tipo ?? "Casa",
      quartos: p.quartos ?? 0,
      banheiros: p.banheiros ?? 0,
      area_m2: Number(p.area_m2) || 0,
      vagas: p.vagas ?? 0,
      descricao: p.descricao ?? "",
      palavras_chave: p.palavras_chave ?? "",
      destaque: !!p.destaque,
    });
    setPhotos(
      Array.isArray(p.imagens) && p.imagens.length
        ? p.imagens
        : p.imagem_capa
        ? [p.imagem_capa]
        : []
    );
    setEditId(p.id);
    setShowForm(true);
  };

  const handlePhotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    setUploading(true);
    try {
      const uploaded: string[] = [];
      for (const file of Array.from(files)) {
        try {
          const url = await uploadPropertyImage(file);
          uploaded.push(url);
        } catch (err: any) {
          toast.error(`Falha ao enviar ${file.name}: ${err.message}`);
        }
      }
      setPhotos((prev) => [...prev, ...uploaded]);
      if (uploaded.length) toast.success(`${uploaded.length} foto(s) enviada(s).`);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const removePhoto = (idx: number) => setPhotos((prev) => prev.filter((_, i) => i !== idx));

  const handleSave = async () => {
    if (!form.titulo.trim()) {
      toast.error("Informe o título do imóvel.");
      return;
    }
    setSaving(true);
    const payload: PropertyInput = {
      titulo: form.titulo.trim(),
      preco: Number(form.preco) || 0,
      preco_formatado: formatBRL(Number(form.preco) || 0),
      localizacao: form.localizacao,
      tipo: form.tipo,
      quartos: Number(form.quartos) || 0,
      banheiros: Number(form.banheiros) || 0,
      vagas: Number(form.vagas) || 0,
      area_m2: Number(form.area_m2) || 0,
      descricao: form.descricao,
      imagem_capa: photos[0] || "",
      imagens: photos,
      ativo: true,
    };

    try {
      if (editId) {
        await updateProperty(editId, payload);
        toast.success("Imóvel atualizado.");
      } else {
        await addProperty(payload);
        toast.success("Imóvel cadastrado.");
      }
      setShowForm(false);
    } catch (err: any) {
      toast.error(err.message || "Erro ao salvar.");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Excluir este imóvel?")) return;
    try {
      await deleteProperty(id);
      toast.success("Imóvel excluído.");
    } catch (err: any) {
      toast.error(err.message || "Erro ao excluir.");
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setAuthenticated(false);
  };

  const updateField = (key: string, value: string | number | boolean) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const showList = !showForm && (activeTab === "meus" || activeTab === "gerenciar");
  const showDashboard = !showForm && activeTab === "dashboard";
  const showConfig = !showForm && activeTab === "config";

  return (
    <AdminShell
      onLogout={handleLogout}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onAdd={openNew}
    >
      {!showForm && (
        <h1 className="text-2xl font-bold text-zinc-900 tracking-tight mb-5">
          {activeTab === "dashboard" && "Dashboard"}
          {activeTab === "meus" && "Meus Imóveis"}
          {activeTab === "gerenciar" && "Gerenciar"}
          {activeTab === "config" && "Configurações"}
        </h1>
      )}

      {showDashboard && (
        <div className="space-y-3">
          <StatCard label="Imóveis Ativos" value={ativos} />
          <StatCard label="Imóveis Pausados" value={pausados} />
          <StatCard label="Total Cadastrados" value={items.length} />
          <StatCard label="Valor Total Catálogo" value={formatTotal(totalValue)} />
        </div>
      )}

      {showList && (
        <>
          <div className="flex items-center gap-2 mb-4">
            <div className="relative flex-1">
              <Search
                className="absolute left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400"
                strokeWidth={1.8}
              />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar imóvel…"
                className="w-full h-11 pl-10 pr-4 rounded-full bg-white border border-zinc-200 text-[13px] text-zinc-900 placeholder:text-zinc-400 outline-none focus:border-[#0070f3] transition-all duration-200"
              />
            </div>
            <button
              onClick={openNew}
              className="h-11 w-11 rounded-full bg-[#0070f3] hover:bg-[#0060df] text-white shadow-[0_4px_12px_rgba(0,112,243,0.3)] transition-all active:scale-95 flex items-center justify-center"
              aria-label="Adicionar"
            >
              <Plus className="w-4 h-4" strokeWidth={2.4} />
            </button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-16 text-zinc-500 text-[12px]">
              <Loader2 className="w-4 h-4 animate-spin mr-2" /> Carregando…
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16 text-zinc-400 text-[13px]">
              {query ? "Nenhum resultado." : "Nenhum imóvel cadastrado ainda."}
            </div>
          ) : (
            <PropertyCarousel
              items={filtered}
              formatBRL={formatBRL}
              onEdit={openEdit}
              onDelete={handleDelete}
            />
          )}
        </>
      )}

      {showConfig && (
        <div className="space-y-3">
          <div className="rounded-2xl bg-white border border-zinc-200/70 p-5">
            <h2 className="text-[14px] font-semibold text-zinc-900 mb-1">
              Importar imóveis de exemplo
            </h2>
            <p className="text-[12px] text-zinc-500 mb-4 leading-relaxed">
              Adiciona os 6 imóveis que aparecem na Home ao seu painel, prontos para
              editar ou excluir. Não duplica os que já existirem.
            </p>
            <button
              disabled={seeding}
              onClick={async () => {
                if (!confirm("Importar os 6 imóveis de exemplo agora?")) return;
                setSeeding(true);
                const t = toast.loading("Iniciando importação…");
                try {
                  const { inserted } = await seedExampleProperties((msg) => {
                    toast.loading(msg, { id: t });
                  });
                  toast.success(
                    inserted === 0
                      ? "Tudo já estava importado."
                      : `${inserted} imóvel(eis) importado(s).`,
                    { id: t },
                  );
                } catch (err: any) {
                  toast.error(err.message || "Falha ao importar.", { id: t });
                } finally {
                  setSeeding(false);
                }
              }}
              className="inline-flex items-center gap-2 h-10 px-4 rounded-full bg-[#0070f3] hover:bg-[#0060df] text-white text-[12px] font-medium transition-all active:scale-95 disabled:opacity-60"
            >
              {seeding ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" strokeWidth={2} />
              )}
              {seeding ? "Importando…" : "Importar agora"}
            </button>
          </div>
        </div>
      )}

      {showForm && (
        <PropertyForm
          editId={editId}
          form={form}
          photos={photos}
          uploading={uploading}
          saving={saving}
          fileInputRef={fileInputRef}
          onClose={() => setShowForm(false)}
          onSave={handleSave}
          updateField={updateField}
          onPhotos={handlePhotos}
          removePhoto={removePhoto}
        />
      )}
    </AdminShell>
  );
};

export default AdminDashboard;
