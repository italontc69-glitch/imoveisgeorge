import { useLayoutEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Search, Building2, BedDouble, Bath, Maximize, MapPin, ArrowRight } from "lucide-react";
import { useProperties } from "@/hooks/useProperties";

type Finalidade = "Todos" | "Compra" | "Aluguel" | "Empreendimentos";
const finalidades: Finalidade[] = ["Todos", "Compra", "Aluguel", "Empreendimentos"];

const Catalogo = () => {
  const properties = useProperties();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get("q") ?? "");
  const [tipo, setTipo] = useState(searchParams.get("tipo") ?? "");
  const [finalidade, setFinalidade] = useState<Finalidade>("Todos");

  useLayoutEffect(() => {
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, []);

  const tipos = useMemo(() => {
    const s = new Set<string>();
    properties.forEach((p) => {
      const t = p.title.split(" ")[0];
      if (t) s.add(t);
    });
    return ["", ...Array.from(s)];
  }, [properties]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return properties.filter((p) => {
      const matchQ =
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.price.toLowerCase().includes(q);
      const matchT = !tipo || p.title.toLowerCase().includes(tipo.toLowerCase());
      const matchF =
        finalidade === "Todos" ||
        p.title.toLowerCase().includes(finalidade.toLowerCase()) ||
        p.description.toLowerCase().includes(finalidade.toLowerCase());
      return matchQ && matchT && matchF;
    });
  }, [properties, query, tipo, finalidade]);

  return (
    <div className="min-h-screen bg-white">
      <div className="sticky top-0 z-[999] bg-white border-b border-zinc-200 shadow-[0_2px_12px_-6px_rgba(0,0,0,0.08)]">
        <div className="max-w-3xl mx-auto px-5">
          {/* Top bar */}
          <div className="h-12 flex items-center justify-between">
            <button
              onClick={() => navigate("/", { replace: true })}
              className="flex items-center gap-1 text-[13px] text-zinc-700 hover:text-zinc-900 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" strokeWidth={2} />
              Voltar
            </button>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 border-2 border-[#1e3a8a] rounded-md rotate-45 flex items-center justify-center">
                <span className="text-[#1e3a8a] font-serif font-bold text-[10px] -rotate-45">G</span>
              </div>
              <p className="font-serif text-[12px] font-semibold text-zinc-900">George Imóveis</p>
            </div>
          </div>

          {/* Título compacto */}
          <div className="pt-1 pb-2 flex items-end justify-between gap-3">
            <h1 className="text-[20px] sm:text-2xl font-bold text-zinc-900 tracking-tight leading-none">
              Catálogo de Imóveis
            </h1>
            <p className="text-[11px] text-zinc-500 shrink-0">
              {filtered.length} {filtered.length === 1 ? "imóvel" : "imóveis"}
            </p>
          </div>

          {/* Filtros */}
          <div className="pb-3 space-y-2">
            <div className="relative">
              <Search
                className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400"
                strokeWidth={1.8}
              />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Pesquisar por nome, localização, tipo ou preço…"
                className="w-full h-11 pl-11 pr-4 rounded-full bg-white border border-zinc-200 text-[13px] text-zinc-900 placeholder:text-zinc-400 outline-none focus:border-[#1e3a8a] focus:ring-2 focus:ring-[#1e3a8a]/10 transition-all"
              />
            </div>

            <div className="relative">
              <Building2
                className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400"
                strokeWidth={1.8}
              />
              <select
                value={tipo}
                onChange={(e) => setTipo(e.target.value)}
                className="w-full h-11 pl-11 pr-4 rounded-full bg-white border border-zinc-200 text-[13px] text-zinc-900 outline-none focus:border-[#1e3a8a] focus:ring-2 focus:ring-[#1e3a8a]/10 transition-all appearance-none cursor-pointer"
              >
                {tipos.map((t) => (
                  <option key={t || "all"} value={t}>
                    {t || "Tipo do Imóvel"}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2 overflow-x-auto -mx-1 px-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {finalidades.map((f) => {
                const active = finalidade === f;
                return (
                  <button
                    key={f}
                    onClick={() => setFinalidade(f)}
                    className={`shrink-0 px-4 h-8 rounded-full text-[12px] font-medium transition-all ${
                      active
                        ? "bg-zinc-900 text-white shadow-sm"
                        : "bg-white text-zinc-700 border border-zinc-200 hover:border-zinc-400"
                    }`}
                  >
                    {f}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <main className="relative z-0 pb-16">
        <div className="max-w-3xl mx-auto px-5 pt-5">
        <div className="mt-6 space-y-5">
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-zinc-400 text-[13px]">
              Nenhum imóvel encontrado.
            </div>
          ) : (
            filtered.map((p) => (
              <Link
                key={p.id}
                to={`/imovel/${p.id}`}
                replace
                className="block bg-white rounded-2xl border border-zinc-200/70 shadow-[0_1px_2px_rgba(16,24,40,0.04),0_4px_16px_-8px_rgba(16,24,40,0.08)] overflow-hidden hover:shadow-[0_8px_28px_-8px_rgba(16,24,40,0.18)] transition-all group"
              >
                <div className="relative w-full aspect-[16/10] overflow-hidden bg-zinc-100">
                  <img
                    src={p.img}
                    alt={p.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-[15px] text-zinc-900">{p.title}</h3>
                  <p className="text-[12px] text-zinc-500 flex items-center gap-1 mt-1">
                    <MapPin className="w-3.5 h-3.5" strokeWidth={1.8} />
                    {p.location}
                  </p>
                  <p className="text-[#1e3a8a] font-bold text-[18px] mt-2">{p.price}</p>
                  <div className="flex items-center gap-4 text-[11px] text-zinc-500 mt-2">
                    <span className="flex items-center gap-1">
                      <BedDouble className="w-3.5 h-3.5 text-[#1e3a8a]" />
                      {p.beds} Quartos
                    </span>
                    <span className="flex items-center gap-1">
                      <Bath className="w-3.5 h-3.5 text-[#1e3a8a]" />
                      {p.baths} Banheiros
                    </span>
                    <span className="flex items-center gap-1">
                      <Maximize className="w-3.5 h-3.5 text-[#1e3a8a]" />
                      {p.area} m²
                    </span>
                  </div>
                  <div className="mt-4 w-full inline-flex items-center justify-center gap-1.5 text-[13px] font-semibold text-white bg-[#1e3a8a] group-hover:bg-[#1e40af] rounded-xl py-3 transition-all shadow-sm">
                    Ver Detalhes
                    <ArrowRight className="w-4 h-4" strokeWidth={2.2} />
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
        </div>
      </main>
    </div>
  );
};

export default Catalogo;
