import { Phone, ArrowRight, MapPin, Home, Search, BedDouble, Bath, Maximize, CheckCircle, ChevronLeft, ChevronRight } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useRef, useState, useEffect } from "react";
import georgeProfile from "@/assets/george-profile.jpg";
import { useProperties } from "@/hooks/useProperties";
import MobileMenu from "@/components/MobileMenu";
import heroVideo from "../../public/hero-imovel-v2.mp4.asset.json";

const Index = () => {
  const properties = useProperties();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchTipo, setSearchTipo] = useState("");

  const goCatalog = (q?: string, t?: string) => {
    const params = new URLSearchParams();
    const query = (q ?? searchTerm).trim();
    const tipo = (t ?? searchTipo).trim();
    if (query) params.set("q", query);
    if (tipo) params.set("tipo", tipo);
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    navigate(`/catalogo${params.toString() ? `?${params}` : ""}`);
  };

  const carouselRef = useRef<HTMLDivElement>(null);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(false);

  const updateArrows = () => {
    const el = carouselRef.current;
    if (!el) return;
    setCanPrev(el.scrollLeft > 4);
    setCanNext(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  };

  useEffect(() => {
    updateArrows();
    const el = carouselRef.current;
    if (!el) return;
    el.addEventListener("scroll", updateArrows, { passive: true });
    window.addEventListener("resize", updateArrows);
    return () => {
      el.removeEventListener("scroll", updateArrows);
      window.removeEventListener("resize", updateArrows);
    };
  }, [properties.length]);

  const scrollByCard = (dir: 1 | -1) => {
    const el = carouselRef.current;
    if (!el) return;
    const first = el.querySelector<HTMLElement>("[data-card]");
    const cardW = first ? first.offsetWidth + 24 : el.clientWidth * 0.85;
    el.scrollBy({ left: dir * cardW, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="min-h-screen relative overflow-hidden bg-[#0f172a]">
        {/* Background video — imóvel leve, fundo escuro p/ destacar texto */}
        <video
          className="absolute inset-0 w-full h-full object-cover z-0"
          autoPlay
          loop
          muted
          playsInline
          preload="auto"
          // @ts-ignore - fetchpriority is valid HTML5
          fetchpriority="high"
          aria-hidden="true"
        >
          <source src={heroVideo.url} type="video/mp4" />
        </video>
        {/* Overlay escuro p/ contraste do título e subtítulo */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70 z-[1] pointer-events-none" />

        <header className="relative z-10 px-4 md:px-16 lg:px-28 py-3">
          <div className="max-w-7xl mx-auto bg-[#1e3a8a0D] backdrop-blur-sm rounded-full px-6 py-2 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 border-2 border-[#1e3a8a] rounded-lg rotate-45 flex items-center justify-center">
                <span className="text-[#1e3a8a] font-serif font-bold text-sm -rotate-45">G</span>
              </div>
              <span className="font-serif text-base font-semibold text-white tracking-tight">
                George Corretor
              </span>
            </div>

            <nav className="hidden md:flex items-center gap-7">
              <a href="#" className="text-xs font-medium text-[#1e3a8a]/80 hover:text-[#1e3a8a] transition-colors uppercase tracking-[0.18em]">Início</a>
              <a href="#" className="text-xs font-medium text-[#1e3a8a]/80 hover:text-[#1e3a8a] transition-colors uppercase tracking-[0.18em]">Sobre</a>
              <a href="#" className="text-xs font-medium text-[#1e3a8a] border-b border-[#1e3a8a] pb-0.5 uppercase tracking-[0.18em]">Imóveis</a>
              <a href="#" className="text-xs font-medium text-[#1e3a8a]/80 hover:text-[#1e3a8a] transition-colors uppercase tracking-[0.18em]">Contato</a>
            </nav>

            <button className="hidden md:flex items-center gap-1.5 bg-[#1e3a8a] text-white px-4 py-1.5 rounded-full text-xs font-medium hover:opacity-90 transition-opacity">
              <Phone className="w-3.5 h-3.5" />
              Contato
            </button>

            <MobileMenu />
          </div>
        </header>

        <div className="relative z-10 max-w-7xl mx-auto px-8 md:px-16 lg:px-28 pt-28 md:pt-16 flex items-center justify-center md:items-start md:justify-start min-h-[70vh] md:min-h-0">
          <div className="flex flex-col gap-4 max-w-sm text-center md:text-left items-center md:items-start">
            <h1 className="font-sans font-extrabold text-white text-3xl md:text-4xl leading-[1.1] tracking-tight drop-shadow-md">
              Realizar<br />seu sonho<br />é o nosso dever.
            </h1>
            <p className="text-white/90 font-semibold text-sm md:text-base leading-relaxed max-w-[240px] drop-shadow-sm">
              A imobiliária que transforma<br />sonhos em lares.
            </p>

            <div className="mt-1 max-w-[280px] w-full">
              <div className="flex items-center bg-white/80 rounded-full pl-4 pr-1 py-0.5 shadow-sm border border-white/30">
                <input
                  type="text"
                  placeholder="Encontre o imóvel ideal"
                  className="flex-1 bg-transparent text-[11px] text-foreground placeholder:text-muted-foreground outline-none py-1.5"
                />
                <button className="flex items-center gap-1 bg-primary text-primary-foreground px-3 py-1.5 rounded-full text-[11px] font-medium hover:opacity-90 transition-opacity whitespace-nowrap">
                  Contato
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <section className="bg-[#f8f8f8]">
        <div className="max-w-7xl mx-auto px-8 md:px-16 lg:px-28 -mt-8 relative z-20">
          <div className="bg-white rounded-2xl shadow-lg p-4 md:p-5 flex flex-col md:flex-row items-stretch md:items-center gap-3 md:gap-4">
            <div className="flex-1 flex items-center gap-2.5 border border-gray-200 rounded-xl px-4 py-2.5 focus-within:border-[#1e3a8a] transition-colors">
              <MapPin className="w-4 h-4 text-[#1e3a8a] shrink-0" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") goCatalog();
                }}
                placeholder="Onde você quer morar?"
                className="flex-1 bg-transparent text-sm text-gray-700 placeholder:text-gray-400 outline-none"
              />
            </div>
            <div className="flex-1 flex items-center gap-2.5 border border-gray-200 rounded-xl px-4 py-2.5 focus-within:border-[#1e3a8a] transition-colors">
              <Home className="w-4 h-4 text-[#1e3a8a] shrink-0" />
              <select
                value={searchTipo}
                onChange={(e) => {
                  setSearchTipo(e.target.value);
                  if (e.target.value) goCatalog(undefined, e.target.value);
                }}
                className="flex-1 bg-transparent text-sm text-gray-700 outline-none appearance-none cursor-pointer"
              >
                <option value="">Tipo de Imóvel</option>
                <option value="Casa">Casa</option>
                <option value="Apartamento">Apartamento</option>
                <option value="Terreno">Terreno</option>
              </select>
            </div>
            <button
              onClick={() => goCatalog()}
              className="flex items-center justify-center gap-2 bg-[#1e3a8a] text-white px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-[#1e3a8a]/90 transition-colors whitespace-nowrap"
            >
              <Search className="w-4 h-4" />
              Buscar Imóveis
            </button>
          </div>
        </div>

        {/* Property Grid */}
        <div className="max-w-7xl mx-auto px-8 md:px-16 lg:px-28 py-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Melhores Imóveis</h2>
          <p className="text-sm text-gray-500 mb-8">Seleção exclusiva dos melhores imóveis disponíveis</p>

          <div className="relative -mx-8 md:-mx-16 lg:-mx-28">
            <div
              ref={carouselRef}
              className="flex flex-row flex-nowrap gap-6 overflow-x-auto overflow-y-hidden pl-8 md:pl-16 lg:pl-28 pr-8 md:pr-16 lg:pr-28 pb-4 snap-x snap-mandatory scroll-smooth [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden"
              style={{ WebkitOverflowScrolling: "touch" }}
            >
              {properties.map((p, i) => (
                <div
                  key={i}
                  data-card
                  className="snap-start shrink-0 grow-0 basis-[85%] sm:basis-[340px] lg:basis-[360px] bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden group"
                >
                  <Link to={`/imovel/${p.id}`} className="relative overflow-hidden block">
                    <img
                      src={p.img}
                      alt={p.title}
                      loading={i < 3 ? "eager" : "lazy"}
                      decoding="async"
                      width={640}
                      height={512}
                      className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </Link>
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 text-sm mb-1">{p.title}</h3>
                    <p className="text-[#1e3a8a] font-bold text-lg mb-3">{p.price}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <BedDouble className="w-3.5 h-3.5 text-[#1e3a8a]" />
                        {p.beds} Quartos
                      </span>
                      <span className="flex items-center gap-1">
                        <Bath className="w-3.5 h-3.5 text-[#1e3a8a]" />
                        {p.baths} Banheiros
                      </span>
                      <span className="flex items-center gap-1">
                        <Maximize className="w-3.5 h-3.5 text-[#1e3a8a]" />
                        {p.area} m²
                      </span>
                    </div>
                    <Link
                      to={`/imovel/${p.id}`}
                      className="mt-4 w-full inline-flex items-center justify-center gap-1.5 text-xs font-semibold text-white bg-[#1e3a8a] hover:bg-[#1e40af] rounded-xl py-2.5 transition-all shadow-sm hover:shadow-md active:scale-[0.98]"
                    >
                      Ver Detalhes
                      <ArrowRight className="w-3.5 h-3.5" strokeWidth={2.2} />
                    </Link>
                  </div>
                </div>
              ))}
            </div>

            {canPrev && (
              <button
                onClick={() => scrollByCard(-1)}
                aria-label="Anterior"
                className="absolute left-2 md:left-6 top-1/2 -translate-y-1/2 z-10 w-11 h-11 rounded-full bg-white shadow-lg border border-gray-200 text-[#1e3a8a] hover:bg-[#1e3a8a] hover:text-white transition-all flex items-center justify-center active:scale-90"
              >
                <ChevronLeft className="w-5 h-5" strokeWidth={2.2} />
              </button>
            )}
            {canNext && (
              <button
                onClick={() => scrollByCard(1)}
                aria-label="Próximo"
                className="absolute right-2 md:right-6 top-1/2 -translate-y-1/2 z-10 w-11 h-11 rounded-full bg-white shadow-lg border border-gray-200 text-[#1e3a8a] hover:bg-[#1e3a8a] hover:text-white transition-all flex items-center justify-center active:scale-90"
              >
                <ChevronRight className="w-5 h-5" strokeWidth={2.2} />
              </button>
            )}
          </div>

          <div className="mt-8 flex justify-center">
            <Link
              to="/catalogo"
              onClick={() => {
                window.scrollTo(0, 0);
                document.documentElement.scrollTop = 0;
                document.body.scrollTop = 0;
              }}
              className="inline-flex items-center gap-2 px-6 h-11 rounded-full bg-white border border-[#1e3a8a]/20 text-[#1e3a8a] text-[13px] font-medium hover:bg-[#1e3a8a] hover:text-white hover:border-[#1e3a8a] transition-all shadow-sm hover:shadow-md active:scale-95"
            >
              Ver todos os imóveis
              <ArrowRight className="w-4 h-4" strokeWidth={2} />
            </Link>
          </div>
        </div>

        {/* O Legado — About George */}
        <div className="bg-[#0f172a] py-20">
          <div className="max-w-7xl mx-auto px-8 md:px-16 lg:px-28">
            <div className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 p-8 md:p-14">
              <div className="flex flex-col md:flex-row items-center gap-12">
                <div className="shrink-0">
                  <img
                    src={georgeProfile}
                    alt="George - Corretor de Imóveis"
                    className="w-60 h-72 md:w-72 md:h-80 rounded-2xl object-cover shadow-2xl"
                  />
                </div>
                <div>
                  <h2 className="text-2xl md:text-3xl font-bold text-white mb-5 leading-tight">
                    George Corretor — 17 Anos<br />Consolidando Legados.
                  </h2>
                  <p className="text-sm md:text-base text-white/80 leading-relaxed mb-4">
                    Há mais de 17 anos, George não apenas negocia propriedades; ele estrutura o palco onde a vida das famílias potiguares acontece. Sua jornada começou movida pela busca incessante daquela sensação indescritível de segurança e conquista que só o primeiro lar proporciona.
                  </p>
                  <p className="text-sm md:text-base text-white/80 leading-relaxed mb-6">
                    Hoje, como referência em negociações de alto padrão no Rio Grande do Norte, George une a precisão técnica à sensibilidade humana. Cada chave entregue é o resultado de uma curadoria estratégica, onde a ética e a transparência são os pilares de cada contrato.
                  </p>
                  <div className="flex items-center gap-2.5 bg-white/10 rounded-xl px-5 py-3 w-fit border border-amber-400/30">
                    <CheckCircle className="w-5 h-5 text-amber-400" />
                    <span className="text-sm font-semibold text-amber-300 tracking-wide">CRECI-RN 3.906 — Corretor Verificado</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Por que comprar com a gente */}
        <div className="bg-[#1A1A1A] py-20">
          <div className="max-w-7xl mx-auto px-8 md:px-16 lg:px-28">
            <div className="flex justify-center mb-3">
              <h2 className="text-2xl md:text-3xl font-bold text-black bg-[#FACC15] px-6 py-2 rounded-full inline-block">Por que comprar com a gente?</h2>
            </div>
            <p className="text-sm text-white/50 text-center mb-14 max-w-lg mx-auto">Descubra o que nos diferencia no mercado imobiliário potiguar.</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              {[
                { title: "Curadoria de Valor", text: "O preço é o que você paga, mas o valor é o que você leva. Nossa metodologia de Curadoria Estratégica não busca apenas casas; analisamos a valorização do solo e o potencial de revenda. Comprar com a gente é garantir um patrimônio que cresce." },
                { title: "Engenharia de Oportunidade", text: "O maior erro é o estresse financeiro. Encontramos o imóvel que cabe no seu bolso sem sacrificar seu estilo de vida. Garimpamos o mercado para entregar apenas o 'filé mignon' das ofertas de Natal." },
                { title: "Garantia da Experiência", text: "São 17 anos de mercado e o respaldo do CRECI-RN 3.906. Não vendemos imóveis, entregamos segurança jurídica e o olhar de quem já viveu todos os ciclos do mercado potiguar." },
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="shrink-0 mt-1">
                    <div className="w-9 h-9 rounded-full bg-[#FACC15]/20 flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-[#FACC15]" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-base mb-2"><span className="text-[#FACC15]">{item.title}</span></h3>
                    <p className="text-white/80 text-sm leading-relaxed">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center">
              <button className="bg-[#FACC15] hover:bg-[#EAB308] text-black font-semibold px-8 py-3.5 rounded-full text-sm tracking-wide transition-colors shadow-lg shadow-[#FACC15]/20">
                Realizar seu Sonho — Falar com Especialista
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
