import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, BedDouble, Bath, Maximize, Car, MapPin, Phone, MessageCircle, ChevronLeft, ChevronRight } from "lucide-react";
import { useProperties } from "@/hooks/useProperties";
import { useEffect, useRef, useState } from "react";
import { CONTACT_TEL, buildWhatsAppUrl } from "@/lib/contact";

const PropertyDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const allProperties = useProperties();
  const property = allProperties.find((p) => p.id === id);
  const [activeCategory, setActiveCategory] = useState(0);
  const [activeImage, setActiveImage] = useState(0);
  const touchStartX = useRef<number | null>(null);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [id]);

  if (!property) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#f8f8f8]">
        <p className="text-gray-600 text-lg mb-4">Imóvel não encontrado.</p>
        <Link to="/" className="text-[#1e3a8a] font-medium hover:underline flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" /> Voltar para a lista
        </Link>
      </div>
    );
  }

  const galleryImages = property.images?.length ? property.images : property.categories.flatMap((category) => category.images);
  const currentImages = property.categories[activeCategory]?.images ?? galleryImages;
  const total = galleryImages.length;
  const goPrev = () => setActiveImage((i) => (i - 1 + total) % total);
  const goNext = () => setActiveImage((i) => (i + 1) % total);
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current == null || total <= 1) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 40) (dx < 0 ? goNext : goPrev)();
    touchStartX.current = null;
  };
  const whatsappUrl = buildWhatsAppUrl(
    `Olá, vim pelo Google. Tenho interesse no imóvel: ${property.title}`,
  );

  return (
    <div className="min-h-screen bg-[#f8f8f8]">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-6 md:px-16 lg:px-28 py-3 flex items-center justify-between">
          <button
            onClick={() => navigate("/catalogo", { replace: true })}
            className="flex items-center gap-2 text-[#1e3a8a] font-medium text-sm hover:opacity-80 transition-opacity"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </button>
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 border-2 border-[#1e3a8a] rounded-lg rotate-45 flex items-center justify-center">
              <span className="text-[#1e3a8a] font-serif font-bold text-xs -rotate-45">G</span>
            </div>
            <span className="font-serif text-sm font-semibold text-[#1e3a8a] tracking-tight">George Imóveis</span>
          </div>
        </div>
      </header>

      {/* Gallery */}
      <section className="max-w-7xl mx-auto px-6 md:px-16 lg:px-28 pt-8">
        {/* Category Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
          {property.categories.map((cat, i) => (
            <button
              key={cat.label}
              onClick={() => {
                setActiveCategory(i);
                const firstCategoryImage = cat.images[0];
                const galleryIndex = galleryImages.findIndex((image) => image === firstCategoryImage);
                setActiveImage(galleryIndex >= 0 ? galleryIndex : 0);
              }}
              className={`px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                i === activeCategory
                  ? "bg-[#1e3a8a] text-white"
                  : "bg-white text-gray-600 border border-gray-200 hover:border-[#1e3a8a]/30"
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Main Image - Carousel */}
        <div
          className="relative rounded-2xl overflow-hidden mb-3 bg-zinc-100 select-none"
          onTouchStart={onTouchStart}
          onTouchEnd={onTouchEnd}
        >
          <img
            key={activeImage}
            src={galleryImages[activeImage] || galleryImages[0]}
            alt={`${property.title} - ${property.categories[activeCategory]?.label} ${activeImage + 1}`}
            loading="eager"
            decoding="async"
            className="w-full h-[300px] md:h-[480px] object-cover animate-fade-in"
          />

          {total > 1 && (
            <>
              <button
                type="button"
                onClick={goPrev}
                aria-label="Foto anterior"
                className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-10 h-10 md:w-11 md:h-11 rounded-full bg-white/70 hover:bg-white text-zinc-900 backdrop-blur-md shadow-md flex items-center justify-center transition-all active:scale-90"
              >
                <ChevronLeft className="w-5 h-5" strokeWidth={2.4} />
              </button>
              <button
                type="button"
                onClick={goNext}
                aria-label="Próxima foto"
                className="absolute right-3 md:right-4 top-1/2 -translate-y-1/2 w-10 h-10 md:w-11 md:h-11 rounded-full bg-white/70 hover:bg-white text-zinc-900 backdrop-blur-md shadow-md flex items-center justify-center transition-all active:scale-90"
              >
                <ChevronRight className="w-5 h-5" strokeWidth={2.4} />
              </button>

              <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-full bg-black/55 text-white text-[11px] font-medium tabular-nums backdrop-blur-sm">
                {activeImage + 1} / {total}
              </div>

              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                {galleryImages.map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    aria-label={`Ir para foto ${i + 1}`}
                    onClick={() => setActiveImage(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      i === activeImage ? "w-5 bg-white" : "w-1.5 bg-white/60 hover:bg-white/90"
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* Thumbnails */}
        {currentImages.length > 1 && (
          <div className="flex gap-3 overflow-x-auto pb-2">
            {galleryImages.map((img, i) => (
              <button
                key={i}
                onClick={() => setActiveImage(i)}
                className={`shrink-0 rounded-xl overflow-hidden border-2 transition-colors ${
                  i === activeImage ? "border-[#1e3a8a]" : "border-transparent"
                }`}
              >
                <img src={img} alt="" className="w-20 h-16 md:w-28 md:h-20 object-cover" />
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Info Section */}
      <section className="max-w-7xl mx-auto px-6 md:px-16 lg:px-28 py-10">
        <div className="flex flex-col lg:flex-row gap-10">
          {/* Left: Details */}
          <div className="flex-1">
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">{property.title}</h1>
            <div className="flex items-center gap-1.5 text-gray-500 text-sm mb-5">
              <MapPin className="w-4 h-4 text-[#1e3a8a]" />
              {property.location}
            </div>

            {/* Specs Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              {[
                { icon: BedDouble, label: "Quartos", value: property.beds },
                { icon: Bath, label: "Banheiros", value: property.baths },
                { icon: Maximize, label: "Área", value: `${property.area} m²` },
                { icon: Car, label: "Vagas", value: property.garage },
              ].map((spec) => (
                <div key={spec.label} className="bg-white rounded-xl p-4 text-center border border-gray-100">
                  <spec.icon className="w-5 h-5 text-[#1e3a8a] mx-auto mb-2" />
                  <p className="text-lg font-bold text-gray-900">{spec.value}</p>
                  <p className="text-xs text-gray-500">{spec.label}</p>
                </div>
              ))}
            </div>

            {/* Description */}
            <h2 className="text-lg font-semibold text-gray-900 mb-3">Sobre o Imóvel</h2>
            <p className="text-sm text-gray-600 leading-relaxed">{property.description}</p>
          </div>

          {/* Right: Price & CTA Card */}
          <div className="lg:w-80 shrink-0">
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sticky top-20 shadow-sm">
              <p className="text-xs text-gray-500 mb-1">Valor de Venda</p>
              <p className="text-2xl font-bold text-[#1e3a8a] mb-6">{property.price}</p>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl py-3 text-sm transition-colors w-full mb-3"
              >
                <MessageCircle className="w-4 h-4" />
                Agendar Visita via WhatsApp
              </a>

              <a
                href={CONTACT_TEL}
                className="flex items-center justify-center gap-2 border border-[#1e3a8a]/20 text-[#1e3a8a] font-medium rounded-xl py-3 text-sm hover:bg-[#1e3a8a] hover:text-white transition-colors w-full"
              >
                <Phone className="w-4 h-4" />
                Ligar Agora
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* CTA flutuante mobile */}
      <div className="lg:hidden sticky bottom-0 inset-x-0 z-20 bg-white/95 backdrop-blur-xl border-t border-zinc-200 px-4 py-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))] flex items-center gap-2 shadow-[0_-8px_24px_-12px_rgba(0,0,0,0.18)]">
        <a
          href={CONTACT_TEL}
          aria-label="Ligar"
          className="w-12 h-12 shrink-0 rounded-full border border-[#1e3a8a]/20 text-[#1e3a8a] hover:bg-[#1e3a8a] hover:text-white transition-colors flex items-center justify-center"
        >
          <Phone className="w-5 h-5" />
        </a>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 h-12 rounded-full bg-green-600 hover:bg-green-700 text-white font-semibold text-[14px] flex items-center justify-center gap-2 transition-colors active:scale-[0.98]"
        >
          <MessageCircle className="w-4 h-4" />
          Falar com Consultor
        </a>
      </div>
    </div>
  );
};

export default PropertyDetails;
